<x-layout>
    <x-slot:title>{{ $title }}</x-slot:title>
    
    <!-- Hero Section -->
    <div class="relative bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 overflow-hidden">
        <div class="absolute inset-0 bg-white/30"></div>
        <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
            <div class="text-center">
                <h1 class="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                    About 
                    <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                        Me
                    </span>
                </h1>
                <p class="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                    Hi, I'm {{ $name }} - a passionate developer and content creator sharing my journey in technology and programming.
                </p>
            </div>
        </div>
        
        <!-- Decorative Elements -->
        <div class="absolute top-20 left-10 w-24 h-24 bg-blue-200 rounded-full opacity-20 animate-pulse"></div>
        <div class="absolute bottom-20 right-20 w-16 h-16 bg-indigo-200 rounded-full opacity-20 animate-bounce"></div>
    </div>

    <!-- Personal Introduction -->
    <div class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                    <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Hello, I'm {{ $name }}</h2>
                    <p class="text-lg text-gray-600 mb-6">
                        I'm a web developer with a passion for creating beautiful, functional, and user-friendly applications. 
                        My journey in programming started several years ago, and I've been continuously learning and growing ever since.
                    </p>
                    <p class="text-lg text-gray-600 mb-6">
                        I specialize in modern web technologies including Laravel, PHP, JavaScript, and various frontend frameworks. 
                        I love solving complex problems and turning ideas into reality through code.
                    </p>
                    <p class="text-lg text-gray-600">
                        When I'm not coding, you can find me writing technical articles, exploring new technologies, 
                        or sharing my knowledge with the developer community.
                    </p>
                </div>
                <div class="bg-gradient-to-br from-blue-100 to-indigo-100 rounded-2xl p-8 lg:p-12">
                    <div class="text-center">
                        <div class="w-32 h-32 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
                            <svg class="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                            </svg>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-900 mb-4">{{ $name }}</h3>
                        <p class="text-gray-700 font-medium mb-2">Full Stack Developer</p>
                        <p class="text-gray-600">
                            Passionate about creating amazing web experiences and sharing knowledge with the community.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Skills Section -->
    <div class="py-16 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">My Skills & Expertise</h2>
                <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                    Technologies and tools I work with to bring ideas to life
                </p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Skill 1 -->
                <div class="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-3">Laravel & PHP</h3>
                    <p class="text-gray-600">
                        Building robust backend applications with Laravel framework and modern PHP practices.
                    </p>
                </div>

                <!-- Skill 2 -->
                <div class="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-yellow-100 rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-3">JavaScript & Frontend</h3>
                    <p class="text-gray-600">
                        Creating interactive user interfaces with modern JavaScript, HTML5, CSS3, and various frameworks.
                    </p>
                </div>

                <!-- Skill 3 -->
                <div class="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-3">Database Design</h3>
                    <p class="text-gray-600">
                        Designing efficient database structures and optimizing queries for better performance.
                    </p>
                </div>

                <!-- Skill 4 -->
                <div class="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-3">Problem Solving</h3>
                    <p class="text-gray-600">
                        Analytical thinking and creative problem-solving to tackle complex technical challenges.
                    </p>
                </div>

                <!-- Skill 5 -->
                <div class="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-3">Content Writing</h3>
                    <p class="text-gray-600">
                        Writing technical articles and documentation to share knowledge with the developer community.
                    </p>
                </div>

                <!-- Skill 6 -->
                <div class="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-3">Team Collaboration</h3>
                    <p class="text-gray-600">
                        Working effectively in teams using Git, Agile methodologies, and modern development workflows.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- My Journey Section -->
    <div class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div class="bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl p-8 lg:p-12">
                    <div class="text-center">
                        <div class="w-24 h-24 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
                            <svg class="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                            </svg>
                        </div>
                        <div class="text-4xl font-bold text-indigo-600 mb-2">2019</div>
                        <div class="text-gray-700 font-medium">Started Programming</div>
                    </div>
                </div>
                <div>
                    <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-6">My Journey</h2>
                    <p class="text-lg text-gray-600 mb-6">
                        My programming journey began in 2019 when I first discovered the power of code. 
                        What started as curiosity quickly turned into a passion for creating digital solutions 
                        that can make a real difference in people's lives.
                    </p>
                    <p class="text-lg text-gray-600 mb-6">
                        Over the years, I've worked on various projects ranging from simple websites to complex 
                        web applications. Each project has taught me something new and helped me grow as a developer.
                    </p>
                    <p class="text-lg text-gray-600">
                        Today, I continue to learn new technologies, contribute to open-source projects, 
                        and share my knowledge through writing and mentoring other developers.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact CTA -->
    <div class="py-16 bg-gradient-to-r from-blue-600 to-indigo-600">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 class="text-3xl md:text-4xl font-bold text-white mb-4">
                Let's Connect
            </h2>
            <p class="text-xl text-blue-100 mb-8">
                I'm always interested in new opportunities and collaborations. Let's build something amazing together!
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="{{ route('contact') }}" class="inline-flex items-center px-8 py-3 border-2 border-white text-base font-medium rounded-lg text-white hover:bg-white hover:text-blue-600 transform hover:scale-105 transition-all duration-200">
                    Get In Touch
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                    </svg>
                </a>
            </div>
        </div>
    </div>
</x-layout>
