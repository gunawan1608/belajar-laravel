<x-layout>
    <x-slot:title>{{ $title }}</x-slot:title>
    
    <!-- Hero Section -->
    <div class="relative bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 overflow-hidden">
        <div class="absolute inset-0 bg-white/30"></div>
        <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
            <div class="text-center">
                <h1 class="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                    Latest 
                    <span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-600">
                        Articles
                    </span>
                </h1>
                <p class="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                    Discover insights, stories, and knowledge from our community of writers and experts.
                </p>
            </div>
        </div>
        
        <!-- Decorative Elements -->
        <div class="absolute top-20 left-10 w-20 h-20 bg-purple-200 rounded-full opacity-20 animate-pulse"></div>
        <div class="absolute bottom-20 right-20 w-16 h-16 bg-blue-200 rounded-full opacity-20 animate-bounce"></div>
    </div>

    <!-- Articles Grid -->
    <div class="bg-gray-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                @foreach ($posts as $post)
                    <article class="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 overflow-hidden group">
                        <!-- Article Image Placeholder -->
                        <div class="h-48 bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center relative overflow-hidden">
                            <div class="absolute inset-0 bg-gradient-to-br from-purple-400/20 to-blue-400/20 group-hover:from-purple-500/30 group-hover:to-blue-500/30 transition-all duration-300"></div>
                            <svg class="w-16 h-16 text-purple-400 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path>
                            </svg>
                        </div>
                        
                        <div class="p-6">
                            <!-- Author Info -->
                            <div class="flex items-center space-x-3 mb-4">
                                <img src="{{ $post->author_image }}" 
                                    alt="{{ $post->author->name }}" 
                                    class="w-10 h-10 rounded-full border-2 border-gray-200">
                                <div class="flex-1 min-w-0">
                                    <h4 class="text-sm font-semibold text-gray-900 truncate">
                                        <a href="/author/{{ $post->author->username }}" class="hover:text-purple-600 transition-colors">
                                            {{ $post->author->name }}
                                        </a>
                                    </h4>
                                    <p class="text-xs text-gray-500">{{ $post->created_at->diffForHumans() }}</p>
                                </div>
                            </div>
                            
                            <!-- Article Title -->
                            <h2 class="text-xl font-bold text-gray-900 mb-3 line-clamp-2 group-hover:text-purple-600 transition-colors">
                                <a href="/posts/{{ $post->slug }}" class="hover:underline">
                                    {{ $post->title }}
                                </a>
                            </h2>
                            
                            <!-- Article Excerpt -->
                            <p class="text-gray-600 mb-4 line-clamp-3 leading-relaxed">
                                {{ Str::limit($post->body, 120) }}
                            </p>
                            
                            <!-- Categories -->
                            <div class="flex flex-wrap gap-2 mb-4">
                                @foreach ($post->categories as $category)
                                    <a href="/categories/{{ $category->slug }}" 
                                        class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800 hover:bg-purple-200 transition-colors">
                                        {{ $category->name }}
                                    </a>
                                @endforeach
                            </div>
                            
                            <!-- Read More Button -->
                            <div class="flex items-center justify-between">
                                <a href="/posts/{{ $post->slug }}" 
                                    class="inline-flex items-center text-purple-600 hover:text-purple-800 font-medium text-sm transition-colors">
                                    Read More
                                    <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path>
                                    </svg>
                                </a>
                                
                                <!-- Reading Time -->
                                <span class="text-xs text-gray-500 flex items-center">
                                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    {{ ceil(str_word_count(strip_tags($post->body)) / 200) }} min read
                                </span>
                            </div>
                        </div>
                    </article>
                @endforeach
            </div>
            
            <!-- Empty State -->
            @if($posts->isEmpty())
                <div class="text-center py-16">
                    <svg class="w-24 h-24 text-gray-300 mx-auto mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path>
                    </svg>
                    <h3 class="text-2xl font-semibold text-gray-900 mb-2">No Articles Found</h3>
                    <p class="text-gray-600 mb-6">We couldn't find any articles matching your criteria.</p>
                    <a href="{{ route('posts') }}" class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-purple-600 hover:bg-purple-700 transition-colors">
                        View All Articles
                    </a>
                </div>
            @endif
        </div>
    </div>

    <!-- Enhanced Pagination -->
    @if(!$posts->isEmpty())
        <div class="bg-white border-t border-gray-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div class="flex flex-col sm:flex-row items-center justify-between">
                    <!-- Results Info -->
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-700">
                            Showing <span class="font-medium">{{ $posts->count() }}</span> articles
                        </p>
                    </div>
                    
                    <!-- Pagination Navigation -->
                    <nav class="flex items-center space-x-2">
                        <a href="#" 
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                            </svg>
                            Previous
                        </a>
                        
                        <div class="hidden sm:flex space-x-1">
                            <a href="#" class="relative inline-flex items-center px-4 py-2 border border-purple-500 text-sm font-medium rounded-lg text-white bg-purple-600 hover:bg-purple-700 transition-colors">
                                1
                            </a>
                            <a href="#" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                                2
                            </a>
                            <a href="#" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                                3
                            </a>
                            <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700">
                                ...
                            </span>
                            <a href="#" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                                10
                            </a>
                        </div>
                        
                        <a href="#" 
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                            Next
                            <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </a>
                    </nav>
                </div>
            </div>
        </div>
    @endif

</x-layout>
