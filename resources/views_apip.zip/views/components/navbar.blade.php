<nav class="w-full z-50 bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-100 sticky top-0">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex h-16 items-center justify-between">

            <!-- Logo -->
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                    </svg>
                </div>
                <span class="text-gray-900 font-bold text-xl tracking-tight">MyWebsite</span>
            </div>

            <!-- Menu Desktop -->
            <div class="hidden md:flex items-center space-x-1">
                <x-nav-link href="/" :active="request()->is('/')">Home</x-nav-link>
                <x-nav-link href="/posts" :active="request()->is('posts')">Blog</x-nav-link>
                <x-nav-link href="/about" :active="request()->is('about')">About</x-nav-link>
                <x-nav-link href="/contact" :active="request()->is('contact')">Contact</x-nav-link>
                <x-nav-link href="/menu" :active="request()->is('menu')">Menu</x-nav-link>
            </div>

            <!-- Right Side Actions -->
            <div class="flex items-center space-x-4">
                <!-- Notification Bell -->
                <button class="relative p-2 text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
                    </svg>
                    <span class="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full flex items-center justify-center">
                        <span class="w-1.5 h-1.5 bg-white rounded-full"></span>
                    </span>
                </button>

                <!-- Mobile Menu Button -->
                <button class="md:hidden p-2 text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors" 
                        x-data="{ open: false }" @click="open = !open">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>

                <!-- Profile Dropdown -->
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" class="flex items-center focus:outline-none">
                        <img src="https://i.pinimg.com/736x/83/d0/90/83d090cc59508af05ff368da39cee41a.jpg"
                             class="w-10 h-10 rounded-full border-2 border-white shadow-md hover:scale-105 transition" />
                    </button>
                    <div x-show="open" @click.away="open=false"
                         class="absolute right-0 mt-3 w-48 bg-white rounded-xl shadow-xl overflow-hidden ring-1 ring-black/5 animate-fadeIn">
                        <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">Your Profile</a>
                        <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50">Settings</a>
                        <a href="#" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50">Sign out</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div class="md:hidden" x-data="{ open: false }" x-show="open" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100" x-transition:leave="transition ease-in duration-150" x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95">
            <div class="px-2 pt-2 pb-3 space-y-1 bg-white border-t border-gray-100">
                <x-nav-link href="/" :active="request()->is('/')" class="block">Home</x-nav-link>
                <x-nav-link href="/posts" :active="request()->is('posts')" class="block">Blog</x-nav-link>
                <x-nav-link href="/about" :active="request()->is('about')" class="block">About</x-nav-link>
                <x-nav-link href="/contact" :active="request()->is('contact')" class="block">Contact</x-nav-link>
                <x-nav-link href="/menu" :active="request()->is('menu')" class="block">Menu</x-nav-link>
                
                <!-- Mobile Search -->
                <div class="pt-4 border-t border-gray-100">
                    <button class="flex items-center space-x-2 w-full px-3 py-2 text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                        <span>Search</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</nav>
