@props(['active' => false])

<a {{ $attributes }}
   class="{{ $active
        ? 'text-indigo-600 font-semibold bg-indigo-50 border border-indigo-200'
        : 'text-gray-700 hover:text-indigo-600 hover:bg-indigo-50' }}
        px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ease-in-out">
   {{ $slot }}
</a>
