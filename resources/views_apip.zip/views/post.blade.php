<x-layout>
    <x-slot:title>{{ $post->title }}</x-slot:title>
    
    <!-- Hero Section -->
    <div class="relative bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 overflow-hidden">
        <div class="absolute inset-0 bg-white/40"></div>
        
        <!-- Decorative Elements -->
        <div class="absolute top-10 left-10 w-32 h-32 bg-blue-200 rounded-full opacity-10 animate-pulse"></div>
        <div class="absolute bottom-10 right-20 w-24 h-24 bg-indigo-200 rounded-full opacity-10 animate-bounce"></div>
        
        <div class="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
            <!-- Back Navigation -->
            <div class="mb-8">
                <a href="/posts" class="inline-flex items-center text-gray-600 hover:text-indigo-600 transition-colors group">
                    <svg class="w-5 h-5 mr-2 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                    Back to Articles
                </a>
            </div>
            
            <!-- Article Header -->
            <div class="text-center mb-8">
                <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                    {{ $post->title }}
                </h1>
                
                <!-- Author Info -->
                <div class="flex items-center justify-center space-x-4 mb-6">
                    <img src="{{ $post->author_image }}" 
                        alt="{{ $post->author->name }}" 
                        class="w-12 h-12 rounded-full border-3 border-white shadow-lg">
                    <div class="text-left">
                        <h3 class="font-semibold text-gray-900">
                            <a href="/author/{{ $post->author->username }}" class="hover:text-indigo-600 transition-colors">
                                {{ $post->author->name }}
                            </a>
                        </h3>
                        <div class="flex items-center text-sm text-gray-600 space-x-4">
                            <span>{{ $post->created_at->format('M d, Y') }}</span>
                            <span>•</span>
                            <span>{{ ceil(str_word_count(strip_tags($post->body)) / 200) }} min read</span>
                        </div>
                    </div>
                </div>
                
                <!-- Categories -->
                <div class="flex flex-wrap justify-center gap-2 mb-8">
                    @foreach ($post->categories as $category)
                        <a href="/categories/{{ $category->slug }}" 
                            class="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800 hover:bg-indigo-200 transition-colors">
                            {{ $category->name }}
                        </a>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    <!-- Article Content -->
    <article class="bg-white">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <!-- Featured Image -->
            @if($post->image)
                <div class="mb-12 rounded-2xl overflow-hidden shadow-2xl">
                    <img src="{{ $post->image }}" 
                        alt="{{ $post->title }}" 
                        class="w-full h-auto object-cover">
                </div>
            @else
                <!-- Placeholder Image -->
                <div class="mb-12 h-96 bg-gradient-to-br from-indigo-100 to-blue-100 rounded-2xl flex items-center justify-center shadow-2xl">
                    <svg class="w-24 h-24 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path>
                    </svg>
                </div>
            @endif
            
            <!-- Article Body -->
            <div class="prose prose-lg prose-indigo max-w-none">
                <div class="text-gray-700 leading-relaxed text-lg">
                    {!! nl2br(e($post->body)) !!}
                </div>
            </div>
        </div>
    </article>

    <!-- Article Footer -->
    <div class="bg-gray-50 border-t border-gray-200">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <!-- Social Actions -->
            <div class="flex items-center justify-between mb-8">
                <div class="flex items-center space-x-6">
                    <button class="flex items-center space-x-2 text-gray-600 hover:text-red-500 transition-colors group">
                        <svg class="w-6 h-6 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                        </svg>
                        <span class="font-medium">42</span>
                    </button>
                    
                    <button class="flex items-center space-x-2 text-gray-600 hover:text-blue-500 transition-colors group">
                        <svg class="w-6 h-6 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                        </svg>
                        <span class="font-medium">18</span>
                    </button>
                </div>
                
                <div class="flex items-center space-x-4">
                    <button class="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"></path>
                        </svg>
                        <span>Share</span>
                    </button>
                </div>
            </div>
            
            <!-- Author Bio -->
            <div class="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
                <div class="flex items-start space-x-6">
                    <img src="{{ $post->author_image }}" 
                        alt="{{ $post->author->name }}" 
                        class="w-20 h-20 rounded-full border-4 border-gray-100 shadow-lg flex-shrink-0">
                    <div class="flex-1">
                        <h3 class="text-2xl font-bold text-gray-900 mb-2">
                            <a href="/author/{{ $post->author->username }}" class="hover:text-indigo-600 transition-colors">
                                {{ $post->author->name }}
                            </a>
                        </h3>
                        <p class="text-gray-600 mb-4 leading-relaxed">
                            Passionate writer and developer sharing insights about technology, programming, and digital innovation. 
                            Always exploring new ways to create meaningful content and connect with the community.
                        </p>
                        <div class="flex items-center space-x-4">
                            <a href="/author/{{ $post->author->username }}" 
                                class="inline-flex items-center px-4 py-2 bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition-colors">
                                View Profile
                            </a>
                            <div class="flex space-x-3">
                                <a href="#" class="text-gray-400 hover:text-indigo-600 transition-colors">
                                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                                    </svg>
                                </a>
                                <a href="#" class="text-gray-400 hover:text-indigo-600 transition-colors">
                                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-layout>
