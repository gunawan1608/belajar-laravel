<x-layout>
    <x-slot:title>{{ $title }}</x-slot:title>
    <h3 class="text-xl">Selamat Datang Di Halaman About</h3>
</x-layout>
